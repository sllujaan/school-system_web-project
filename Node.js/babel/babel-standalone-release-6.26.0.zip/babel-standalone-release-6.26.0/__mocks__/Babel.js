module.exports = require('../babel');
